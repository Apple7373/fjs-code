#include <bits/stdc++.h>

using namespace std;

class CTiangle{
    private:
        int x, y;
    public:
        CTiangle(int y, int x) {
            this->x = x;
            this->y = y;
        }

        CTiangle operator+ (CTiangle c);
        void display() {
            cout << "A(" << 0 <<',' << y << "),B(0,0),C(" << x << ",0)"<<endl; 
        }
};

CTiangle CTiangle::operator+(CTiangle c) {

}

int main()
{
    string s;
    while (cin >> s) {
        cout << s << endl;
        if (cin.get() == '\n') break;
        
    }
}